package com.example.firstapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var mainActivityViewModel:MainActivityViewModel=ViewModelProvider(this).get(MainActivityViewModel::class.java)
        var constraintLayout=findViewById<ConstraintLayout>(R.id.constraintLayout)

        val bmiValue=findViewById<TextView>(R.id.bmiValue)
        val bmiStatus=findViewById<TextView>(R.id.bmiStatus)
        val heightInput=findViewById<EditText>(R.id.heightInput)
        val weightInput=findViewById<EditText>(R.id.weightInput)
        val button=findViewById<Button>(R.id.clbutton)

        bmiValue.text=mainActivityViewModel.bmi.toInt().toString()
        bmiStatus.text=mainActivityViewModel.status

        button.setOnClickListener{
            var height=heightInput.text.toString()
            var weight=weightInput.text.toString()
            if(height!="" && weight!=""){
                var heightMeters=height.toDouble()/100
                var bmi=(weight.toDouble()/(heightMeters*heightMeters))
                mainActivityViewModel.changeBmi(bmi)
                bmiValue.text=mainActivityViewModel.bmi.toInt().toString()
                var status:String=""
                when{
                    bmi<18.5 -> {
                        status="Underweight"
                    }
                    bmi>=18.5 && bmi<25.0 ->{
                        status="Normal"
                    }
                    bmi>=25.0 && bmi<30.0 ->{
                        status="OverWeight"
                    }
                    else->{
                        status="Obesity"
                }
                }
                mainActivityViewModel.changeStatus(status)
                bmiStatus.text=mainActivityViewModel.status
                bmiValue.text=bmi.toInt().toString()
            }
            else{
                var snackbar=Snackbar.make(constraintLayout,"Height or Weight is missing!!",Snackbar.LENGTH_SHORT)
                snackbar.show()
            }
        }

    }
}