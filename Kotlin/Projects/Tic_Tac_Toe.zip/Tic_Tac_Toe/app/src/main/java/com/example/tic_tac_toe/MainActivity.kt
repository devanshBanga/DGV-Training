package com.example.tic_tac_toe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var btn1=findViewById<TextView>(R.id.tv1)
        var btn2=findViewById<TextView>(R.id.tv2)
        var btn3=findViewById<TextView>(R.id.tv3)
        var btn4=findViewById<TextView>(R.id.tv4)
        var btn5=findViewById<TextView>(R.id.tv5)
        var btn6=findViewById<TextView>(R.id.tv6)
        var btn7=findViewById<TextView>(R.id.tv7)
        var btn8=findViewById<TextView>(R.id.tv8)
        var btn9=findViewById<TextView>(R.id.tv9)
        var displayResult=findViewById<TextView>(R.id.displayResult)
        var playAgain=findViewById<Button>(R.id.playAgain)
        var count:Int=0
        var matrix = arrayOf<String>("1","2","3","4","5","6","7","8","9")
        fun winGame() {
            if (
                (matrix[0] == matrix[4] && matrix[4] == matrix[8]) ||
                (matrix[2] == matrix[4] && matrix[4] == matrix[6]) ||
                (matrix[0] == matrix[1] && matrix[1] == matrix[2]) ||
                (matrix[3] == matrix[4] && matrix[4] == matrix[5]) ||
                (matrix[6] == matrix[7] && matrix[7] == matrix[8]) ||
                (matrix[0] == matrix[3] && matrix[3] == matrix[6]) ||
                (matrix[1] == matrix[4] && matrix[4] == matrix[7]) ||
                (matrix[2] == matrix[5] && matrix[5] == matrix[8])
            ) {
                if (count%2==0) {
                    displayResult.text="Player2 wins!!"
                } else {
                    displayResult.text="Player1 wins!!"
                }
            }else if(count==9 && matrix[8]!="9"){
                displayResult.text="Draw!!"
            }
        }
        fun working(){
            btn1.setOnClickListener{
                if(count%2==0){
                    btn1.text="X"
                }else{
                    btn1.text="O"
                }
                matrix[0]=btn1.text.toString()
                count++
                winGame()
            }
            btn2.setOnClickListener{
                if(count%2==0){
                    btn2.text="X"
                }else{
                    btn2.text="O"
                }
                matrix[1]=btn2.text.toString()
                count++
                winGame()
            }
            btn3.setOnClickListener{
                if(count%2==0){
                    btn3.text="X"
                }else{
                    btn3.text="O"
                }
                matrix[2]=btn3.text.toString()
                count++
                winGame()
            }
            btn4.setOnClickListener{
                if(count%2==0){
                    btn4.text="X"
                }else{
                    btn4.text="O"
                }
                matrix[3]=btn4.text.toString()
                count++
                winGame()
            }
            btn5.setOnClickListener{
                if(count%2==0){
                    btn5.text="X"
                }else{
                    btn5.text="O"
                }
                matrix[4]=btn5.text.toString()
                count++
                winGame()
            }
            btn6.setOnClickListener{
                if(count%2==0){
                    btn6.text="X"
                }else{
                    btn6.text="O"
                }
                matrix[5]=btn6.text.toString()
                count++
                winGame()
            }
            btn7.setOnClickListener{
                if(count%2==0){
                    btn7.text="X"
                }else{
                    btn7.text="O"
                }
                matrix[6]=btn7.text.toString()
                count++
                winGame()
            }
            btn8.setOnClickListener{
                if(count%2==0){
                    btn8.text="X"
                }else{
                    btn8.text="O"
                }
                matrix[7]=btn8.text.toString()
                count++
                winGame()
            }
            btn9.setOnClickListener{
                if(count%2==0){
                    btn9.text="X"
                }else{
                    btn9.text="O"
                }
                matrix[8]=btn9.text.toString()
                count++
                winGame()
            }
        }
        working()
        playAgain.setOnClickListener{
            btn1.text=""
            btn2.text=""
            btn3.text=""
            btn4.text=""
            btn5.text=""
            btn6.text=""
            btn7.text=""
            btn8.text=""
            btn9.text=""
            count=0
            displayResult.text="Result"
            matrix = arrayOf<String>("1","2","3","4","5","6","7","8","9")
            working()
        }
    }
}